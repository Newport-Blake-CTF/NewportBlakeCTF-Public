#!/bin/sh

./qemu-arm -L . ./coal-mine