# Template exploit

This specific template uses rust, however c or c++ will work fine as well.
Running `make build` will generate a shared library that can be sent to remote.